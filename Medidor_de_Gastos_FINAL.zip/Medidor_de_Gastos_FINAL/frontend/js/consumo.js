const API = '/api/movimientos';
let movimientos = [];
const $ = id => document.getElementById(id);
const money = value => new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(Number(value));

async function request(url, options={}) {
  const response = await fetch(url, {headers:{'Content-Type':'application/json', ...(options.headers||{})}, ...options});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.message || 'Ocurrió un error.');
  return data;
}

async function cargar() {
  try {
    const health = await request('/api/health');
    $('status').textContent = health.ok ? 'Servidor conectado' : 'Sin conexión';
    const result = await request(API);
    movimientos = result.data || [];
    render();
  } catch (error) {
    $('status').textContent = 'Revisar servidor / MySQL';
    $('tabla').innerHTML = `<tr><td colspan="5">No se pudo cargar la información: ${error.message}</td></tr>`;
  }
}

function render() {
  const text = $('buscar').value.trim().toLowerCase();
  const type = $('filtroTipo').value;
  const filtrados = movimientos.filter(m => (!text || m.categoria.toLowerCase().includes(text)) && (type==='Todos' || m.tipo===type));
  $('tabla').innerHTML = filtrados.map(m => `<tr>
    <td>${m.fecha}</td><td>${escapeHtml(m.categoria)}</td>
    <td><span class="badge ${m.tipo==='Ingreso'?'income':'expense'}">${m.tipo}</span></td>
    <td><strong>${money(m.monto)}</strong></td>
    <td><div class="row-actions"><button class="edit" onclick="editar(${m.id_gasto})">Editar</button><button class="danger" onclick="eliminar(${m.id_gasto})">Eliminar</button></div></td>
  </tr>`).join('');
  $('vacio').style.display = filtrados.length ? 'none' : 'block';
  const ingresos = movimientos.filter(m=>m.tipo==='Ingreso').reduce((s,m)=>s+Number(m.monto),0);
  const gastos = movimientos.filter(m=>m.tipo==='Gasto').reduce((s,m)=>s+Number(m.monto),0);
  $('totalIngresos').textContent=money(ingresos); $('totalGastos').textContent=money(gastos); $('saldo').textContent=money(ingresos-gastos); $('cantidad').textContent=movimientos.length;
}

$('gastoForm').addEventListener('submit', async e => {
  e.preventDefault();
  const id = $('id_gasto').value;
  const body = {monto:Number($('monto').value),categoria:$('categoria').value.trim(),fecha:$('fecha').value,tipo:$('tipo').value};
  try { const data=await request(id?`${API}/${id}`:API,{method:id?'PUT':'POST',body:JSON.stringify(body)}); mostrar(data.message); limpiar(); await cargar(); }
  catch(error){ mostrar(error.message,true); }
});

function editar(id){ const m=movimientos.find(x=>x.id_gasto==id); if(!m)return; $('id_gasto').value=m.id_gasto; $('monto').value=m.monto; $('categoria').value=m.categoria; $('fecha').value=m.fecha; $('tipo').value=m.tipo; $('formTitle').textContent='Editar'; $('cancelar').classList.remove('hidden'); window.scrollTo({top:0,behavior:'smooth'}); }
async function eliminar(id){ if(!confirm('¿Eliminar este movimiento?'))return; try{const d=await request(`${API}/${id}`,{method:'DELETE'});mostrar(d.message);await cargar();}catch(e){mostrar(e.message,true)} }
function limpiar(){ $('gastoForm').reset(); $('id_gasto').value=''; $('fecha').value=new Date().toISOString().slice(0,10); $('tipo').value='Gasto'; $('formTitle').textContent='Registrar'; $('cancelar').classList.add('hidden'); }
function mostrar(msg,error=false){$('mensaje').textContent=msg;$('mensaje').style.color=error?'#b42318':'#16704a';setTimeout(()=>{$('mensaje').textContent=''},3500)}
function escapeHtml(value){return String(value).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
$('cancelar').addEventListener('click',limpiar); $('recargar').addEventListener('click',cargar); $('buscar').addEventListener('input',render); $('filtroTipo').addEventListener('change',render);
limpiar(); cargar();
