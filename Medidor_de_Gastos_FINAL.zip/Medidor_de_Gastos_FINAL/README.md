# Medidor de Gastos — versión integrada

Proyecto integrado de frontend + backend + MySQL.

## 1. Base de datos
1. Abrir MySQL Workbench o phpMyAdmin.
2. Ejecutar completo `backend/config/database.sql`.
3. Por defecto el proyecto usa `root`, contraseña vacía y MySQL en `localhost:3306`.

Si tu MySQL tiene otra configuración, define antes de iniciar:
`DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_PORT`, `DB_NAME`.

## 2. Instalar y ejecutar
Desde la carpeta `backend`:

```bash
npm install
npm start
```

Abrir: http://localhost:3000

## 3. Funciones
- Registrar ingresos y gastos.
- Consultar movimientos desde MySQL.
- Editar movimientos.
- Eliminar movimientos.
- Filtrar por tipo y categoría.
- Buscar movimientos.
- Resumen de ingresos, gastos y saldo.
- Interfaz responsive.
- API REST en `/api/movimientos`.
- Ruta compatible `/api/movimiento` conservada del proyecto anterior.
