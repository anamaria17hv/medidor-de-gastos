const model = require('../model/gastos.model');

function validar(datos) {
  const { monto, categoria, fecha, tipo } = datos;
  if (monto === undefined || Number(monto) <= 0) return 'El monto debe ser mayor que 0.';
  if (!categoria || !String(categoria).trim()) return 'La categoría es obligatoria.';
  if (!fecha || !/^\d{4}-\d{2}-\d{2}$/.test(fecha)) return 'La fecha no es válida.';
  if (!['Ingreso', 'Gasto'].includes(tipo)) return 'El tipo debe ser Ingreso o Gasto.';
  return null;
}

class GastosController {
  static async consultarGastos(req, res, next) {
    try { res.json({ data: await model.listar() }); } catch (error) { next(error); }
  }

  static async obtenerGasto(req, res, next) {
    try {
      const gasto = await model.obtenerPorId(req.params.id);
      if (!gasto) return res.status(404).json({ message: 'Movimiento no encontrado.' });
      res.json({ data: gasto });
    } catch (error) { next(error); }
  }

  static async crearGasto(req, res, next) {
    try {
      const error = validar(req.body);
      if (error) return res.status(400).json({ message: error });
      const gasto = await model.crear(req.body);
      res.status(201).json({ message: 'Movimiento guardado correctamente.', data: gasto });
    } catch (error) { next(error); }
  }

  static async actualizarGasto(req, res, next) {
    try {
      const error = validar(req.body);
      if (error) return res.status(400).json({ message: error });
      const gasto = await model.actualizar(req.params.id, req.body);
      if (!gasto) return res.status(404).json({ message: 'Movimiento no encontrado.' });
      res.json({ message: 'Movimiento actualizado correctamente.', data: gasto });
    } catch (error) { next(error); }
  }

  static async eliminarGasto(req, res, next) {
    try {
      const eliminado = await model.eliminar(req.params.id);
      if (!eliminado) return res.status(404).json({ message: 'Movimiento no encontrado.' });
      res.json({ message: 'Movimiento eliminado correctamente.' });
    } catch (error) { next(error); }
  }
}

module.exports = GastosController;
