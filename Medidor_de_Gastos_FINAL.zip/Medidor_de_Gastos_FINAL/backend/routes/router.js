const express = require('express');
const controller = require('../controller/gastos.controller');
const router = express.Router();

router.get('/movimientos', controller.consultarGastos);
router.get('/movimiento', controller.consultarGastos); // compatibilidad con la ruta anterior
router.get('/movimientos/:id', controller.obtenerGasto);
router.post('/movimientos', controller.crearGasto);
router.put('/movimientos/:id', controller.actualizarGasto);
router.delete('/movimientos/:id', controller.eliminarGasto);

module.exports = router;
