CREATE DATABASE IF NOT EXISTS medidor_de_gastos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE medidor_de_gastos;

DROP TABLE IF EXISTS gastos;
CREATE TABLE gastos (
  id_gasto INT NOT NULL AUTO_INCREMENT,
  monto DECIMAL(12,2) NOT NULL,
  categoria VARCHAR(100) NOT NULL,
  fecha DATE NOT NULL,
  tipo ENUM('Ingreso','Gasto') NOT NULL,
  PRIMARY KEY (id_gasto)
) ENGINE=InnoDB;

INSERT INTO gastos (monto, categoria, fecha, tipo) VALUES
(25000.00, 'Comida', '2026-08-13', 'Gasto'),
(500000.00, 'Salario', '2026-08-01', 'Ingreso'),
(45000.00, 'Transporte', '2026-08-12', 'Gasto'),
(120000.00, 'Servicios', '2026-08-10', 'Gasto'),
(80000.00, 'Venta', '2026-08-15', 'Ingreso'),
(35000.00, 'Entretenimiento', '2026-08-16', 'Gasto'),
(60000.00, 'Mercado', '2026-08-17', 'Gasto'),
(150000.00, 'Freelance', '2026-08-18', 'Ingreso'),
(20000.00, 'Transporte', '2026-08-19', 'Gasto'),
(55000.00, 'Salud', '2026-08-20', 'Gasto');

SELECT * FROM gastos ORDER BY fecha DESC, id_gasto DESC;
