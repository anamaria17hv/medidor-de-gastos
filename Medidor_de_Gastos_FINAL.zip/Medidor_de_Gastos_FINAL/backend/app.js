const express = require('express');
const path = require('path');
const router = require('./routes/router');

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.use('/api', router);

app.get('/api/health', (req, res) => res.json({ ok: true, message: 'Servidor funcionando.' }));

app.use((req, res) => res.status(404).json({ message: 'Ruta no encontrada.' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Error interno del servidor.', detail: process.env.NODE_ENV === 'development' ? err.message : undefined });
});

app.listen(PORT, () => console.log(`Medidor de Gastos funcionando en http://localhost:${PORT}`));
