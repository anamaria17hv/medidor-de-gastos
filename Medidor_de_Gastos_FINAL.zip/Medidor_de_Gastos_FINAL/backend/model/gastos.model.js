const db = require('../config/db');

class GastosModel {
  static async listar() {
    const [rows] = await db.query('SELECT id_gasto, monto, categoria, fecha, tipo FROM gastos ORDER BY fecha DESC, id_gasto DESC');
    return rows;
  }

  static async obtenerPorId(id) {
    const [rows] = await db.execute('SELECT id_gasto, monto, categoria, fecha, tipo FROM gastos WHERE id_gasto = ?', [id]);
    return rows[0];
  }

  static async crear({ monto, categoria, fecha, tipo }) {
    const [result] = await db.execute(
      'INSERT INTO gastos (monto, categoria, fecha, tipo) VALUES (?, ?, ?, ?)',
      [monto, categoria, fecha, tipo]
    );
    return this.obtenerPorId(result.insertId);
  }

  static async actualizar(id, { monto, categoria, fecha, tipo }) {
    const [result] = await db.execute(
      'UPDATE gastos SET monto = ?, categoria = ?, fecha = ?, tipo = ? WHERE id_gasto = ?',
      [monto, categoria, fecha, tipo, id]
    );
    if (!result.affectedRows) return null;
    return this.obtenerPorId(id);
  }

  static async eliminar(id) {
    const [result] = await db.execute('DELETE FROM gastos WHERE id_gasto = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = GastosModel;
